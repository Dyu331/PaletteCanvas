//
//  CreditView.swift
//  PalettePlaygroundApp
//
//  Created by Danny Yu on 4/15/23.
//

import SwiftUI

struct CreditView: View {
    var body: some View {
            NavigationView{
                VStack{

                    Text("Developer: Danny Yu").bold().padding()
                    Text("Image Sources:").bold()
                    Text("Painting with Green Center: https://www.artic.edu/artworks/8987/painting-with-green-center ").padding()
                    Text("The Milkmaid: https://en.wikipedia.org/wiki/The_Milkmaid_%28Vermeer%29").padding()
                    Text("The Scream: https://www.edvardmunch.org/the-scream.jsp").padding()
                    Text("The Olive Trees: https://www.moma.org/collection/works/80013").padding()
                    Text("Portrait of a Young Girl: https://artistryfound.com/monochromatic-color-paintings/ ").padding(.leading).padding(.trailing)
                    Text("Reference Tools").bold().padding()
                    Text("Color Palette Picker: https://coolors.co/").padding()
                    Text("Color Reference Tool: https://www.color-hex.com/")
                }
            }.navigationTitle("Credits")
    }
}

struct CreditView_Previews: PreviewProvider {
    static var previews: some View {
        CreditView()
    }
}
